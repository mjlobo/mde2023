async function createVisualizations() {
  // ---- DATA LOADING ----- //
  var trains = await aq.loadCSV(
    "https://mjlobo.github.io/teaching/mde/data/2023/small_trains.csv"
  );
  var gares = await aq.loadCSV(
    "https://mjlobo.github.io/teaching/mde/data/2023/garesdep@1.csv"
  );
  var trainswithdate = trains.derive({
    date: (d) => op.datetime(d.year, d.month - 1),
  });

  // ---- TABLE CREATION ----- //

  trainsByStationsAndDate = trainswithdate
    .groupby("date", "departure_station", "arrival_station")
    .rollup({
      total_num_trips: (d) => op.mean(d.total_num_trips),
      num_late_at_departure: (d) => op.mean(d.num_late_at_departure),
      num_arriving_late: (d) => op.mean(d.num_arriving_late),
      avg_delay_all_departing: (d) => op.mean(d.avg_delay_all_departing),
      avg_delay_all_arriving: (d) => op.mean(d.avg_delay_all_arriving),
    });
  trainsByStations = trainsByStationsAndDate
    .groupby("departure_station", "arrival_station")
    .rollup({
      total_num_trips: (d) => op.sum(d.total_num_trips),
      num_late_at_departure: (d) => op.sum(d.num_late_at_departure),
      num_arriving_late: (d) => op.sum(d.num_arriving_late),
      avg_delay_all_departing: (d) => op.mean(d.avg_delay_all_departing),
      avg_delay_all_arriving: (d) => op.mean(d.avg_delay_all_arriving),
    })
    .derive({
      ratio_late_at_departure: (d) =>
        d.num_late_at_departure / d.total_num_trips,
    });

  // EXERCISES
  createVisualizationsQ5(gares, trainsByStations);
}

function createVisualizationsQ5(gares, trainsByStations) {
  var further1 = {
    $schema: "https://vega.github.io/schema/vega-lite/v5.json",
    width: 500,
    height: 300,
    layer: [
      {
        data: {
          url: "https://mjlobo.github.io/teaching/eivp/departements.json",
          format: {
            type: "topojson",
            feature: "departements",
          },
        },
        projection: {
          type: "mercator",
        },
        mark: {
          type: "geoshape",
          fill: "lightgray",
          stroke: "white",
        },
      },
      {
        data: {
          values: trainsByStations.objects(),
        },
        params: [
          {
            name: "paintbrush",
            select: {
              type: "point",
              on: "mouseover",
              fields: ["arrival_station"],
            },
            nearest: true,
          },
        ],
        transform: [
          {
            aggregate: [{ op: "count", as: "routes" }],
            groupby: ["arrival_station"],
          },
          {
            lookup: "arrival_station",
            from: {
              data: { values: gares.objects() },
              key: "LIBELLE",
              fields: ["X_WGS84", "Y_WGS84"],
            },
          },
          { filter: "datum.X_WGS84 != null && datum.Y_WGS84 != null" },
        ],
        projection: {
          type: "mercator",
        },
        mark: { type: "point" },
        encoding: {
          longitude: {
            field: "X_WGS84",
            type: "quantitative",
          },
          latitude: {
            field: "Y_WGS84",
            type: "quantitative",
          },
          tooltip: { field: "arrival_station", type: "nominal" },
          size: {
            condition: { param: "paintbrush", value: 300, empty: false },
            value: 50,
          },
          color: { value: "steelblue" },
        },
      },
      {
        data: {
          values: trainsByStations.objects(),
        },
        transform: [
          {
            lookup: "departure_station",
            from: {
              data: { values: gares.objects() },
              key: "LIBELLE",
              fields: ["X_WGS84", "Y_WGS84"],
            },
            //as: ["X_WGS84_departure", "Y_WGS84_departure"]
          },
          {
            lookup: "arrival_station",
            from: {
              data: { values: gares.objects() },
              key: "LIBELLE",
              fields: ["X_WGS84", "Y_WGS84"],
            },
            as: ["X_WGS84_arrival", "Y_WGS84_arrival"],
          },

          {
            filter: {
              param: "paintbrush",
              //"empty": false
            },
          },
          {
            filter:
              "datum.X_WGS84!= null && datum.Y_WGS84 != null && datum.X_WGS84_arrival!= null && datum.Y_WGS84_arrival != null",
          },
        ],
        projection: {
          type: "mercator",
        },
        mark: "rule",
        encoding: {
          longitude: {
            field: "X_WGS84",
            type: "quantitative",
          },
          latitude: {
            field: "Y_WGS84",
            type: "quantitative",
          },
          longitude2: {
            field: "X_WGS84_arrival",
            type: "quantitative",
          },
          latitude2: {
            field: "Y_WGS84_arrival",
            type: "quantitative",
          },
          // color: {"value": "steelblue"},
          color: {
            field: "total_num_trips",
            type: "quantitative",
          },
        },
      },
    ],
  };
  vegaEmbed("#further_1", further1);
}

createVisualizations();
