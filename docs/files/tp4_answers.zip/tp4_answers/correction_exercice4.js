async function createVisualizations() {
  // ---- DATA LOADING ----- //
  var trains = await aq.loadCSV(
    "https://mjlobo.github.io/teaching/mde/data/2023/small_trains.csv"
  );
  var gares = await aq.loadCSV(
    "https://mjlobo.github.io/teaching/mde/data/2023/garesdep@1.csv"
  );
  var trainswithdate = trains.derive({
    date: (d) => op.datetime(d.year, d.month - 1),
  });

  // ---- TABLE CREATION ----- //

  trainsByStationsAndDate = trainswithdate
    .groupby("date", "departure_station", "arrival_station")
    .rollup({
      total_num_trips: (d) => op.mean(d.total_num_trips),
      num_late_at_departure: (d) => op.mean(d.num_late_at_departure),
      num_arriving_late: (d) => op.mean(d.num_arriving_late),
      avg_delay_all_departing: (d) => op.mean(d.avg_delay_all_departing),
      avg_delay_all_arriving: (d) => op.mean(d.avg_delay_all_arriving),
    });
  trainsByStations = trainsByStationsAndDate
    .groupby("departure_station", "arrival_station")
    .rollup({
      total_num_trips: (d) => op.sum(d.total_num_trips),
      num_late_at_departure: (d) => op.sum(d.num_late_at_departure),
      num_arriving_late: (d) => op.sum(d.num_arriving_late),
      avg_delay_all_departing: (d) => op.mean(d.avg_delay_all_departing),
      avg_delay_all_arriving: (d) => op.mean(d.avg_delay_all_arriving),
    })
    .derive({
      ratio_late_at_departure: (d) =>
        d.num_late_at_departure / d.total_num_trips,
    });

  // EXERCISES
  createVisualizationsQ4(gares, trainsByStations);
}

function createVisualizationsQ4(gares, trainsByStations) {
  var trainsByStationFiltered = trainsByStations
    .semijoin(gares, ["arrival_station", "LIBELLE"])
    .semijoin(gares, ["departure_station", "LIBELLE"])
    .orderby(aq.desc("total_num_trips"))
    .reify()
    .slice(0, 40);

  var linked1 = {
    $schema: "https://vega.github.io/schema/vega-lite/v5.json",
    hconcat: [
      {
        width: 300,
        height: 300,
        data: {
          values: trainsByStationFiltered.objects(),
        },
        params: [
          {
            name: "selected",
            select: { type: "point" },
          },
        ],
        config: {
          view: {
            strokeWidth: 0,
            step: 13,
          },
          axis: {
            domain: false,
          },
        },
        mark: "rect",
        encoding: {
          x: {
            field: "departure_station",
            type: "nominal",
          },
          y: {
            field: "arrival_station",
            type: "nominal",
          },
          color: {
            field: "total_num_trips",
            type: "quantitative",
            legend: {
              title: null,
            },
          },
          stroke: {
            condition: {
              param: "selected",
              value: "orange",
              empty: false,
            },
            value: null,
          },
        },
      },
      {
        layer: [
          {
            data: {
              url: "https://mjlobo.github.io/teaching/eivp/departements.json",
              format: {
                type: "topojson",
                feature: "departements",
              },
            },
            projection: {
              type: "mercator",
            },
            mark: {
              type: "geoshape",
              fill: "lightgray",
              stroke: "white",
            },
          },
          {
            data: {
              values: gares.objects(),
            },
            projection: {
              type: "mercator",
            },
            mark: { type: "point" },
            encoding: {
              longitude: {
                field: "X_WGS84",
                type: "quantitative",
              },
              latitude: {
                field: "Y_WGS84",
                type: "quantitative",
              },
              tooltip: { field: "LIBELLE", type: "nominal" },
              size: { value: 20 },
              color: { value: "steelblue" },
            },
          },
          {
            data: {
              values: trainsByStationFiltered.objects(),
            },
            params: [
              {
                name: "selected",
                select: { type: "point" },
              },
            ],
            transform: [
              {
                lookup: "departure_station",
                from: {
                  data: { values: gares.objects() },
                  key: "LIBELLE",
                  fields: ["X_WGS84", "Y_WGS84"],
                },
                as: ["X_WGS84_departure", "Y_WGS84_departure"],
              },
              {
                lookup: "arrival_station",
                from: {
                  data: { values: gares.objects() },
                  key: "LIBELLE",
                  fields: ["X_WGS84", "Y_WGS84"],
                },
                as: ["X_WGS84_arrival", "Y_WGS84_arrival"],
              },
              {
                filter:
                  "datum.X_WGS84_departure != null && datum.Y_WGS84_departure != null && datum.X_WGS84_arrival           != null && datum.Y_WGS84_arrival != null",
              },
            ],
            projection: {
              type: "mercator",
            },
            mark: "rule",
            encoding: {
              longitude: {
                field: "X_WGS84_departure",
                type: "quantitative",
              },
              latitude: {
                field: "Y_WGS84_departure",
                type: "quantitative",
              },
              longitude2: {
                field: "X_WGS84_arrival",
                type: "quantitative",
              },
              latitude2: {
                field: "Y_WGS84_arrival",
                type: "quantitative",
              },
              color: {
                condition: { param: "selected", value: "orange", empty: false },
                value: "steelblue",
              },
            },
          },
        ],
      },
    ],
  };
  vegaEmbed("#linked_1", linked1);

  //Add a filter according to the total number of trips.
  var maxNumTrains = trainsByStationFiltered
    .rollup({ maxNumTrains: (d) => op.max(d.total_num_trips) })
    .objects()[0].maxNumTrains;
  var linked2 = {
    $schema: "https://vega.github.io/schema/vega-lite/v5.json",
    params: [
      {
        name: "MinNumTrains",
        value: 0,
        bind: { input: "range", min: 0, max: maxNumTrains, step: 100 }, // we define the input type and the minimum and maixmum values
      },
    ],
    hconcat: [
      {
        width: 300,
        height: 300,
        data: {
          values: trainsByStationFiltered.objects(),
        },
        transform: [
          {
            filter: "datum.total_num_trips>MinNumTrains",
          }, //we have an additional filter to take into account the slider
        ],
        params: [
          {
            name: "selected",
            select: { type: "point" },
          },
        ],
        config: {
          view: {
            strokeWidth: 0,
            step: 13,
          },
          axis: {
            domain: false,
          },
        },
        mark: "rect",
        encoding: {
          x: {
            field: "departure_station",
            type: "nominal",
          },
          y: {
            field: "arrival_station",
            type: "nominal",
          },
          color: {
            field: "total_num_trips",
            type: "quantitative",
            legend: {
              title: null,
            },
          },
          stroke: {
            condition: {
              param: "selected",
              value: "orange",
              empty: false,
            },
            value: null,
          },
        },
      },
      {
        layer: [
          {
            data: {
              url: "https://mjlobo.github.io/teaching/eivp/departements.json",
              format: {
                type: "topojson",
                feature: "departements",
              },
            },
            projection: {
              type: "mercator",
            },
            mark: {
              type: "geoshape",
              fill: "lightgray",
              stroke: "white",
            },
          },
          {
            data: {
              values: gares.objects(),
            },
            projection: {
              type: "mercator",
            },
            mark: { type: "point" },
            encoding: {
              longitude: {
                field: "X_WGS84",
                type: "quantitative",
              },
              latitude: {
                field: "Y_WGS84",
                type: "quantitative",
              },
              tooltip: { field: "LIBELLE", type: "nominal" },
              size: { value: 20 },
              color: { value: "steelblue" },
            },
          },
          {
            data: {
              values: trainsByStationFiltered.objects(),
            },
            params: [
              {
                name: "selected",
                select: { type: "point" },
              },
            ],
            transform: [
              {
                lookup: "departure_station",
                from: {
                  data: { values: gares.objects() },
                  key: "LIBELLE",
                  fields: ["X_WGS84", "Y_WGS84"],
                },
                as: ["X_WGS84_departure", "Y_WGS84_departure"],
              },
              {
                lookup: "arrival_station",
                from: {
                  data: { values: gares.objects() },
                  key: "LIBELLE",
                  fields: ["X_WGS84", "Y_WGS84"],
                },
                as: ["X_WGS84_arrival", "Y_WGS84_arrival"],
              },
              {
                filter:
                  "datum.X_WGS84_departure != null && datum.Y_WGS84_departure != null && datum.X_WGS84_arrival!= null && datum.Y_WGS84_arrival != null && datum.total_num_trips>MinNumTrains",
              },
            ],
            projection: {
              type: "mercator",
            },
            mark: "rule",
            encoding: {
              longitude: {
                field: "X_WGS84_departure",
                type: "quantitative",
              },
              latitude: {
                field: "Y_WGS84_departure",
                type: "quantitative",
              },
              longitude2: {
                field: "X_WGS84_arrival",
                type: "quantitative",
              },
              latitude2: {
                field: "Y_WGS84_arrival",
                type: "quantitative",
              },
              color: {
                condition: { param: "selected", value: "orange", empty: false },
                value: "steelblue",
              },
            },
          },
        ],
      },
    ],
  };
  vegaEmbed("#linked_2", linked2);

  //Improve the visual encoding
  var linked3 = {
    $schema: "https://vega.github.io/schema/vega-lite/v5.json",
    hconcat: [
      {
        width: 300,
        height: 300,
        data: {
          values: trainsByStationFiltered.objects(),
        },
        params: [
          {
            name: "selected",
            select: { type: "point" },
          },
        ],
        config: {
          view: {
            strokeWidth: 0,
            step: 13,
          },
          axis: {
            domain: false,
          },
        },
        mark: "rect",
        encoding: {
          x: {
            field: "departure_station",
            type: "nominal",
          },
          y: {
            field: "arrival_station",
            type: "nominal",
          },
          color: {
            field: "total_num_trips",
            type: "quantitative",
            legend: {
              title: null,
            },
          },
          stroke: {
            condition: {
              param: "selected",
              value: "orange",
              empty: false,
            },
            value: null,
          },
        },
      },
      {
        layer: [
          {
            data: {
              url: "https://mjlobo.github.io/teaching/eivp/departements.json",
              format: {
                type: "topojson",
                feature: "departements",
              },
            },
            projection: {
              type: "mercator",
            },
            mark: {
              type: "geoshape",
              fill: "lightgray",
              stroke: "white",
            },
          },
          {
            data: {
              values: gares.objects(),
            },
            projection: {
              type: "mercator",
            },
            mark: { type: "point" },
            encoding: {
              longitude: {
                field: "X_WGS84",
                type: "quantitative",
              },
              latitude: {
                field: "Y_WGS84",
                type: "quantitative",
              },
              tooltip: { field: "LIBELLE", type: "nominal" },
              size: { value: 20 },
              color: { value: "steelblue" },
            },
          },
          {
            data: {
              values: trainsByStationFiltered.objects(),
            },
            params: [
              {
                name: "selected",
                select: { type: "point" },
              },
            ],
            transform: [
              {
                lookup: "departure_station",
                from: {
                  data: { values: gares.objects() },
                  key: "LIBELLE",
                  fields: ["X_WGS84", "Y_WGS84"],
                },
                as: ["X_WGS84_departure", "Y_WGS84_departure"],
              },
              {
                lookup: "arrival_station",
                from: {
                  data: { values: gares.objects() },
                  key: "LIBELLE",
                  fields: ["X_WGS84", "Y_WGS84"],
                },
                as: ["X_WGS84_arrival", "Y_WGS84_arrival"],
              },
              {
                filter:
                  "datum.X_WGS84_departure != null && datum.Y_WGS84_departure != null && datum.X_WGS84_arrival           != null && datum.Y_WGS84_arrival != null",
              },
            ],
            projection: {
              type: "mercator",
            },
            mark: "rule",
            encoding: {
              longitude: {
                field: "X_WGS84_departure",
                type: "quantitative",
              },
              latitude: {
                field: "Y_WGS84_departure",
                type: "quantitative",
              },
              longitude2: {
                field: "X_WGS84_arrival",
                type: "quantitative",
              },
              latitude2: {
                field: "Y_WGS84_arrival",
                type: "quantitative",
              },
              color: {
                condition: { param: "selected", value: "orange", empty: false },
                field: "total_num_trips",
                type: "quantitative",
                scale: {
                  scheme: "plasma",
                },
              },
            },
          },
        ],
      },
    ],
  };
  vegaEmbed("#linked_3", linked3);
}

createVisualizations();
