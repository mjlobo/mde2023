async function createVisualizations() {
  // ---- DATA LOADING ----- //
  var trains = await aq.loadCSV(
    "https://mjlobo.github.io/teaching/mde/data/2023/small_trains.csv"
  );
  var gares = await aq.loadCSV(
    "https://mjlobo.github.io/teaching/mde/data/2023/garesdep@1.csv"
  );
  var trainswithdate = trains.derive({
    date: (d) => op.datetime(d.year, d.month - 1),
  });

  // ---- TABLE CREATION ----- //

  trainsByStationsAndDate = trainswithdate
    .groupby("date", "departure_station", "arrival_station")
    .rollup({
      total_num_trips: (d) => op.mean(d.total_num_trips),
      num_late_at_departure: (d) => op.mean(d.num_late_at_departure),
      num_arriving_late: (d) => op.mean(d.num_arriving_late),
      avg_delay_all_departing: (d) => op.mean(d.avg_delay_all_departing),
      avg_delay_all_arriving: (d) => op.mean(d.avg_delay_all_arriving),
    });
  trainsByStations = trainsByStationsAndDate
    .groupby("departure_station", "arrival_station")
    .rollup({
      total_num_trips: (d) => op.sum(d.total_num_trips),
      num_late_at_departure: (d) => op.sum(d.num_late_at_departure),
      num_arriving_late: (d) => op.sum(d.num_arriving_late),
      avg_delay_all_departing: (d) => op.mean(d.avg_delay_all_departing),
      avg_delay_all_arriving: (d) => op.mean(d.avg_delay_all_arriving),
    })
    .derive({
      ratio_late_at_departure: (d) =>
        d.num_late_at_departure / d.total_num_trips,
    });

  // EXERCISES
  createVisualizationsQ3(gares, trainsByStations);
}

function createVisualizationsQ3(gares, trainsByStations) {
  var multiple1 = {
    $schema: "https://vega.github.io/schema/vega-lite/v5.json",
    width: 400,
    height: 300,
    hconcat: [
      // les vues dans se tableau vont être disposées horizontalement
      {
        layer: [
          {
            data: {
              url: "https://mjlobo.github.io/teaching/eivp/departements.json",
              format: {
                type: "topojson",
                feature: "departements",
              },
            },
            projection: {
              type: "mercator",
            },
            mark: {
              type: "geoshape",
              fill: "lightgray",
              stroke: "white",
            },
          },
          {
            params: [
              {
                name: "selected", //la variable qui va stocker l'objet(s) selectionné
                select: { type: "point", on: "mouseover" }, //type de selection, ici on va sélectionner un point lorsque la souris survole le point
              },
            ],
            data: {
              values: gares.objects(),
            },
            projection: {
              type: "mercator",
            },
            mark: {
              type: "circle",
            },
            encoding: {
              longitude: {
                field: "X_WGS84",
                type: "quantitative",
              },
              latitude: {
                field: "Y_WGS84",
                type: "quantitative",
              },
              tooltip: [{ field: "LIBELLE", type: "nominal" }],
              size: {
                condition: { param: "selected", value: 200, empty: false }, // ici la condition veut dire que si l'objet correspond à l'objet selected, la tailler sera 100, sinon 50. Le paramètre permet de dire que si la sélection est vide on la considère pas comme dans l'objet "selected".
                value: 50,
              },
              color: { value: "steelblue" },
            },
          },
        ],
      },
      {
        layer: [
          {
            data: {
              url: "https://mjlobo.github.io/teaching/eivp/departements.json",
              format: {
                type: "topojson",
                feature: "departements",
              },
            },
            projection: {
              type: "mercator",
            },
            mark: {
              type: "geoshape",
              fill: "lightgray",
              stroke: "white",
            },
          },
          {
            params: [
              {
                name: "selected", //la variable qui va stocker l'objet(s) selectionné
                select: { type: "point", on: "mouseover" }, //type de selection, ici on va sélectionner un point lorsque la souris survole le point
              },
            ],
            data: {
              values: gares.objects(),
            },
            projection: {
              type: "mercator",
            },
            mark: {
              type: "circle",
            },
            encoding: {
              longitude: {
                field: "X_WGS84",
                type: "quantitative",
              },
              latitude: {
                field: "Y_WGS84",
                type: "quantitative",
              },
              tooltip: [{ field: "LIBELLE", type: "nominal" }],
              size: {
                condition: { param: "selected", value: 200, empty: false }, // ici la condition veut dire que si l'objet correspond à l'objet selected, la tailler sera 100, sinon 50. Le paramètre permet de dire que si la sélection est vide on la considère pas comme dans l'objet "selected".
                value: 50,
              },
              color: { value: "steelblue" },
            },
          },
        ],
      },
    ],
  };
  vegaEmbed("#multiple_1", multiple1);

  //1.Use the example below to display in one side the number of departures by station and in the other side the number of arrivals per station. Change the selection so that the color reflects the selected stations.
  var trainsByDepartureStation = trainsByStations
    .groupby("departure_station")
    .rollup({
      total_num_trips: (d) => op.sum(d.total_num_trips),
      num_late_at_departure: (d) => op.sum(d.num_late_at_departure),
      num_arriving_late: (d) => op.sum(d.num_arriving_late),
      avg_delay_all_departing: (d) => op.mean(d.avg_delay_all_departing),
    });

  var trainsByDepartureWithCoords = trainsByDepartureStation
    .join_left(gares, ["departure_station", "LIBELLE"])
    .filter((d) => d.LIBELLE != null)
    .reify();

  var trainsByArrivalStation = trainsByStations
    .groupby("arrival_station")
    .rollup({
      total_num_trips: (d) => op.sum(d.total_num_trips),
      num_late_at_departure: (d) => op.sum(d.num_late_at_departure),
      num_arriving_late: (d) => op.sum(d.num_arriving_late),
      avg_delay_all_arriving: (d) => op.mean(d.avg_delay_all_arriving),
    });

  var trainsByArrivalWithCoords = trainsByArrivalStation
    .join_left(gares, ["arrival_station", "LIBELLE"])
    .filter((d) => d.LIBELLE != null)
    .reify();

  var trainsByDepartureWithCoordsForJoin = trainsByDepartureWithCoords.select({
    departure_station: "departure_station",
    total_num_trips: "total_num_trips_departure",
    avg_delay_all_departing: "avg_delay_all_departing",
    num_late_at_departure: "num_late_at_departure",
  });

  var trainsByArrivalWithCoordsForJoin = trainsByArrivalWithCoords.select({
    arrival_station: "arrival_station",
    total_num_trips: "total_num_trips_arrival",
    avg_delay_all_arriving: "avg_delay_all_arriving",
    num_arriving_late: "num_arriving_late",
    X_WGS84: "X_WGS84",
    Y_WGS84: "Y_WGS84",
    LIBELLE: "LIBELLE",
  });

  var trainsWithArrivalAndDeparture =
    trainsByDepartureWithCoordsForJoin.join_left(
      trainsByArrivalWithCoordsForJoin,
      ["departure_station", "arrival_station"]
    );

  var multiple2 = {
    $schema: "https://vega.github.io/schema/vega-lite/v5.json",
    width: 400,
    height: 300,
    hconcat: [
      // les vues dans se tableau vont être disposées horizontalement
      {
        layer: [
          {
            data: {
              url: "https://mjlobo.github.io/teaching/eivp/departements.json",
              format: {
                type: "topojson",
                feature: "departements",
              },
            },
            projection: {
              type: "mercator",
            },
            mark: {
              type: "geoshape",
              fill: "lightgray",
              stroke: "white",
            },
          },
          {
            params: [
              {
                name: "selected",
                select: { type: "point", on: "mouseover" },
              },
            ],
            data: {
              values: trainsWithArrivalAndDeparture.objects(),
            },
            projection: {
              type: "mercator",
            },
            mark: {
              type: "circle",
            },
            encoding: {
              longitude: {
                field: "X_WGS84",
                type: "quantitative",
              },
              latitude: {
                field: "Y_WGS84",
                type: "quantitative",
              },
              tooltip: [
                { field: "LIBELLE", type: "nominal" },
                {
                  field: "total_num_trips_departure",
                  type: "quantitative",
                },
              ],
              size: {
                field: "total_num_trips_departure",
                type: "quantitative",
              },
              color: {
                condition: { param: "selected", value: "red", empty: false },
                value: "steelblue",
              },
            },
          },
        ],
      },
      {
        layer: [
          {
            data: {
              url: "https://mjlobo.github.io/teaching/eivp/departements.json",
              format: {
                type: "topojson",
                feature: "departements",
              },
            },
            projection: {
              type: "mercator",
            },
            mark: {
              type: "geoshape",
              fill: "lightgray",
              stroke: "white",
            },
          },
          {
            params: [
              {
                name: "selected",
                select: { type: "point", on: "mouseover" },
              },
            ],
            data: {
              values: trainsWithArrivalAndDeparture.objects(),
            },
            projection: {
              type: "mercator",
            },
            mark: {
              type: "circle",
            },
            encoding: {
              longitude: {
                field: "X_WGS84",
                type: "quantitative",
              },
              latitude: {
                field: "Y_WGS84",
                type: "quantitative",
              },
              tooltip: [
                { field: "LIBELLE", type: "nominal" },
                { field: "total_num_trips_arrival", type: "quantitative" },
              ],
              size: {
                field: "total_num_trips_arrival",
                type: "quantitative",
              },
              color: {
                condition: { param: "selected", value: "red", empty: false },
                value: "steelblue",
              },
            },
          },
        ],
      },
    ],
  };
  vegaEmbed("#multiple_2", multiple2);

  //2. Create a second visualization displaying in one side the mean delay time at departure per station and at the other side the mean delay at arrival.
  var multiple3 = {
    $schema: "https://vega.github.io/schema/vega-lite/v5.json",
    width: 400,
    height: 300,
    hconcat: [
      // les vues dans se tableau vont être disposées horizontalement
      {
        layer: [
          {
            data: {
              url: "https://mjlobo.github.io/teaching/eivp/departements.json",
              format: {
                type: "topojson",
                feature: "departements",
              },
            },
            projection: {
              type: "mercator",
            },
            mark: {
              type: "geoshape",
              fill: "lightgray",
              stroke: "white",
            },
          },
          {
            params: [
              {
                name: "selected",
                select: { type: "point", on: "mouseover" },
              },
            ],
            data: {
              values: trainsWithArrivalAndDeparture.objects(),
            },
            projection: {
              type: "mercator",
            },
            mark: {
              type: "circle",
            },
            encoding: {
              longitude: {
                field: "X_WGS84",
                type: "quantitative",
              },
              latitude: {
                field: "Y_WGS84",
                type: "quantitative",
              },
              tooltip: [
                { field: "LIBELLE", type: "nominal" },
                {
                  field: "avg_delay_all_departing",
                  type: "quantitative",
                },
              ],
              size: {
                field: "avg_delay_all_departing",
                type: "quantitative",
              },
              color: {
                condition: { param: "selected", value: "red", empty: false },
                value: "steelblue",
              },
            },
          },
        ],
      },
      {
        layer: [
          {
            data: {
              url: "https://mjlobo.github.io/teaching/eivp/departements.json",
              format: {
                type: "topojson",
                feature: "departements",
              },
            },
            projection: {
              type: "mercator",
            },
            mark: {
              type: "geoshape",
              fill: "lightgray",
              stroke: "white",
            },
          },
          {
            params: [
              {
                name: "selected",
                select: { type: "point", on: "mouseover" },
              },
            ],
            data: {
              values: trainsWithArrivalAndDeparture.objects(),
            },
            projection: {
              type: "mercator",
            },
            mark: {
              type: "circle",
            },
            encoding: {
              longitude: {
                field: "X_WGS84",
                type: "quantitative",
              },
              latitude: {
                field: "Y_WGS84",
                type: "quantitative",
              },
              tooltip: [
                { field: "LIBELLE", type: "nominal" },
                { field: "avg_delay_all_arriving", type: "quantitative" },
              ],
              size: {
                field: "avg_delay_all_arriving",
                type: "quantitative",
              },
              color: {
                condition: { param: "selected", value: "red", empty: false },
                value: "steelblue",
              },
            },
          },
        ],
      },
    ],
  };
  vegaEmbed("#multiple_3", multiple3);

  //Create a visualization with four horizontal views, displaying four different variables. What is the problem if we display a big number of views?
  //to make it easier we create a fonction to create a single view according to a variable
  createViz = (field) => {
    let viz = [
      {
        data: {
          url: "https://mjlobo.github.io/teaching/eivp/departements.json",
          format: {
            type: "topojson",
            feature: "departements",
          },
        },
        projection: {
          type: "mercator",
        },
        mark: {
          type: "geoshape",
          fill: "lightgray",
          stroke: "white",
        },
      },
      {
        data: {
          values: trainsWithArrivalAndDeparture.objects(),
        },
        params: [
          {
            name: "selected",
            select: { type: "point", on: "mouseover" },
          },
        ],
        projection: {
          type: "mercator",
        },
        mark: { type: "circle" },
        encoding: {
          longitude: {
            field: "X_WGS84",
            type: "quantitative",
          },
          latitude: {
            field: "Y_WGS84",
            type: "quantitative",
          },
          size: {
            field: field,
            type: "quantitative",
            legend: {
              title: field,
            },
          },
          color: {
            condition: { param: "selected", value: "red", empty: false },
            value: "steelblue",
          },
          tooltip: [{ field: "LIBELLE", type: "nominal" }],
        },
      },
    ];
    return viz;
  };

  var multiple4 = {
    $schema: "https://vega.github.io/schema/vega-lite/v5.json",
    width: 400,
    height: 300,
    hconcat: [
      // les vues dans se tableau vont être disposées horizontalement
      {
        layer: createViz("num_late_at_departure"),
      },
      {
        layer: createViz("num_arriving_late"),
      },
      {
        layer: createViz("total_num_trips_departure"),
      },
      {
        layer: createViz("total_num_trips_arrival"),
      },
    ],
  };
  vegaEmbed("#multiple_4", multiple4);
}

createVisualizations();
