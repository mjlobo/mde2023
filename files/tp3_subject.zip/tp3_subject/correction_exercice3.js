async function createVisualizations() {
  // ---- DATA LOADING ----- //
  var trains = await aq.loadCSV(
    "https://mjlobo.github.io/teaching/mde/data/2023/small_trains.csv"
  );
  var gares = await aq.loadCSV(
    "https://mjlobo.github.io/teaching/mde/data/2023/garesdep@1.csv"
  );
  var trainswithdate = trains.derive({
    date: (d) => op.datetime(d.year, d.month - 1),
  });

  // ---- TABLE CREATION ----- //

  var trainsByStationsAndDate = trainswithdate
    .groupby("date", "departure_station", "arrival_station")
    .rollup({
      total_num_trips: (d) => op.mean(d.total_num_trips),
      num_late_at_departure: (d) => op.mean(d.num_late_at_departure),
      num_arriving_late: (d) => op.mean(d.num_arriving_late),
    });
  var trainsByStations = trainsByStationsAndDate
    .groupby("departure_station", "arrival_station")
    .rollup({
      total_num_trips: (d) => op.sum(d.total_num_trips),
      num_late_at_departure: (d) => op.sum(d.num_late_at_departure),
      num_arriving_late: (d) => op.sum(d.num_arriving_late),
    })
    .derive({
      ratio_late_at_departure: (d) =>
        d.num_late_at_departure / d.total_num_trips,
    });

  // EXERCISES
  createVisualizationsQ3(gares, trainsByStations);
}

function createVisualizationsQ3(gares, trainsByStations) {
  var lines1 = {
    $schema: "https://vega.github.io/schema/vega-lite/v3.json",
    width: 400,
    height: 300,
    layer: [
      {
        data: {
          url: "https://mjlobo.github.io/teaching/eivp/departements.json",
          format: {
            type: "topojson",
            feature: "departements",
          },
        },
        projection: {
          type: "mercator",
        },
        mark: {
          type: "geoshape",
          fill: "lightgray",
          stroke: "white",
        },
      },
      {
        data: {
          values: gares.objects(),
        },
        projection: {
          type: "mercator",
        },
        mark: { type: "point" },
        encoding: {
          longitude: {
            field: "X_WGS84",
            type: "quantitative",
          },
          latitude: {
            field: "Y_WGS84",
            type: "quantitative",
          },
          size: { value: 20 },
          color: { value: "steelblue" },
        },
      },
      {
        //we add a layer to represent the trips
        data: {
          values: trainsByStations.objects(),
        },
        transform: [
          {
            lookup: "departure_station", // we look for the stations coordiantes with lookup
            from: {
              data: { values: gares.objects() },
              key: "LIBELLE",
              fields: ["X_WGS84", "Y_WGS84"],
            },
            as: ["X_WGS84_departure", "Y_WGS84_departure"],
          },
          {
            lookup: "arrival_station",
            from: {
              data: { values: gares.objects() },
              key: "LIBELLE",
              fields: ["X_WGS84", "Y_WGS84"],
            },
            as: ["X_WGS84_arrival", "Y_WGS84_arrival"],
          },
          {
            filter:
              "datum.X_WGS84_departure != null && datum.Y_WGS84_departure != null && datum.X_WGS84_arrival!= null && datum.Y_WGS84_arrival != null",
          }, // we add a filter to only consider trips coming and going to stations that have valid coordinates
        ],
        projection: {
          type: "mercator",
        },
        mark: "rule",
        encoding: {
          longitude: {
            field: "X_WGS84_departure",
            type: "quantitative",
          },
          latitude: {
            field: "Y_WGS84_departure",
            type: "quantitative",
          },
          longitude2: {
            field: "X_WGS84_arrival",
            type: "quantitative",
          },
          latitude2: {
            field: "Y_WGS84_arrival",
            type: "quantitative",
          },
          color: { value: "steelblue" },
        },
      },
    ],
  };
  vegaEmbed("#lines_1", lines1);

  //1. Represent the number of trips using the color of the lines.

  //2.Represent the number of trips using the width of the lines.

  //3. Represent the number of trips using the opacity of lines.
}

createVisualizations();
