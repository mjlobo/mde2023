async function createVisualizations() {
  // ---- DATA LOADING ----- //
  var trains = await aq.loadCSV(
    "https://mjlobo.github.io/teaching/mde/data/2023/small_trains.csv"
  );
  var gares = await aq.loadCSV(
    "https://mjlobo.github.io/teaching/mde/data/2023/garesdep@1.csv"
  );
  var trainswithdate = trains.derive({
    date: (d) => op.datetime(d.year, d.month - 1),
  });

  // ---- TABLE CREATION ----- //

  var trainsByStationsAndDate = trainswithdate
    .groupby("date", "departure_station", "arrival_station")
    .rollup({
      total_num_trips: (d) => op.mean(d.total_num_trips),
      num_late_at_departure: (d) => op.mean(d.num_late_at_departure),
      num_arriving_late: (d) => op.mean(d.num_arriving_late),
    });
  var trainsByStations = trainsByStationsAndDate
    .groupby("departure_station", "arrival_station")
    .rollup({
      total_num_trips: (d) => op.sum(d.total_num_trips),
      num_late_at_departure: (d) => op.sum(d.num_late_at_departure),
      num_arriving_late: (d) => op.sum(d.num_arriving_late),
    })
    .derive({
      ratio_late_at_departure: (d) =>
        d.num_late_at_departure / d.total_num_trips,
    });

  // EXERCISES
  createVisualizationsQ4(gares, trainsByStations);
}

function createVisualizationsQ4(gares, trainsByStations) {
  // 1. For each station, depict the difference between incoming and outgoing trips using circles. You can test different visual encodings, such as the color of the circle or the size of the circle.
  // 2. Use a visual encoding to depict, for each train station, if the number of incoming trips is larger than the number of outgoing trips
}

createVisualizations();
