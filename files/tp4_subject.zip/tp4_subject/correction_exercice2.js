async function createVisualizations() {
  // ---- DATA LOADING ----- //
  var trains = await aq.loadCSV(
    "https://mjlobo.github.io/teaching/mde/data/2023/small_trains.csv"
  );
  var gares = await aq.loadCSV(
    "https://mjlobo.github.io/teaching/mde/data/2023/garesdep@1.csv"
  );
  var trainswithdate = trains.derive({
    date: (d) => op.datetime(d.year, d.month - 1),
  });

  // ---- TABLE CREATION ----- //

  var trainsByStationsAndDate = trainswithdate
    .groupby("date", "departure_station", "arrival_station")
    .rollup({
      total_num_trips: (d) => op.mean(d.total_num_trips),
      num_late_at_departure: (d) => op.mean(d.num_late_at_departure),
      num_arriving_late: (d) => op.mean(d.num_arriving_late),
    });
  var trainsByStations = trainsByStationsAndDate
    .groupby("departure_station", "arrival_station")
    .rollup({
      total_num_trips: (d) => op.sum(d.total_num_trips),
      num_late_at_departure: (d) => op.sum(d.num_late_at_departure),
      num_arriving_late: (d) => op.sum(d.num_arriving_late),
    })
    .derive({
      ratio_late_at_departure: (d) =>
        d.num_late_at_departure / d.total_num_trips,
    });

  // EXERCISES
  createVisualizationsQ2(gares, trainsByStations);
}

function createVisualizationsQ2(gares, trainsByStations) {
  var maxNumTrains = trainsByStations
    .rollup({ maxNumTrains: (d) => op.max(d.total_num_trips) })
    .objects()[0].maxNumTrains;
  var filter1 = {
    $schema: "https://vega.github.io/schema/vega-lite/v5.json",
    width: 600,
    height: 300,
    params: [
      {
        name: "MinNumTrains",
        value: 0,
        bind: { input: "range", min: 0, max: maxNumTrains, step: 100 }, // we define the input type and the minimum and maixmum values
      },
    ],
    layer: [
      {
        data: {
          url: "https://mjlobo.github.io/teaching/eivp/departements.json",
          format: {
            type: "topojson",
            feature: "departements",
          },
        },
        projection: {
          type: "mercator",
        },
        mark: {
          type: "geoshape",
          fill: "lightgray",
          stroke: "white",
        },
      },
      {
        data: {
          values: gares.objects(),
        },
        projection: {
          type: "mercator",
        },
        mark: { type: "point" },
        encoding: {
          longitude: {
            field: "X_WGS84",
            type: "quantitative",
          },
          latitude: {
            field: "Y_WGS84",
            type: "quantitative",
          },
          tooltip: { field: "LIBELLE", type: "nominal" },
          size: { value: 20 },
          color: { value: "steelblue" },
        },
      },
      {
        data: {
          values: trainsByStations.objects(),
        },
        transform: [
          {
            lookup: "departure_station",
            from: {
              data: { values: gares.objects() },
              key: "LIBELLE",
              fields: ["X_WGS84", "Y_WGS84"],
            },
            as: ["X_WGS84_departure", "Y_WGS84_departure"],
          },
          {
            lookup: "arrival_station",
            from: {
              data: { values: gares.objects() },
              key: "LIBELLE",
              fields: ["X_WGS84", "Y_WGS84"],
            },
            as: ["X_WGS84_arrival", "Y_WGS84_arrival"],
          },
          {
            filter:
              "datum.X_WGS84_departure != null && datum.Y_WGS84_departure != null && datum.X_WGS84_arrival           != null && datum.Y_WGS84_arrival != null && datum.total_num_trips>MinNumTrains",
          }, //we have an additional filter to take into account the slider
        ],
        projection: {
          type: "mercator",
        },
        mark: "rule",
        encoding: {
          longitude: {
            field: "X_WGS84_departure",
            type: "quantitative",
          },
          latitude: {
            field: "Y_WGS84_departure",
            type: "quantitative",
          },
          longitude2: {
            field: "X_WGS84_arrival",
            type: "quantitative",
          },
          latitude2: {
            field: "Y_WGS84_arrival",
            type: "quantitative",
          },
          color: { value: "steelblue" },
        },
      },
    ],
  };
  vegaEmbed("#filter_1", filter1);

  //1. Add another slider to filter also by maximum number of trips
}

createVisualizations();
