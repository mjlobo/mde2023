async function createVisualizations() {
  // ---- DATA LOADING ----- //
  var trains = await aq.loadCSV(
    "https://mjlobo.github.io/teaching/mde/data/2023/small_trains.csv"
  );
  var gares = await aq.loadCSV(
    "https://mjlobo.github.io/teaching/mde/data/2023/garesdep@1.csv"
  );
  var trainswithdate = trains.derive({
    date: (d) => op.datetime(d.year, d.month - 1),
  });

  // ---- TABLE CREATION ----- //

  trainsByStationsAndDate = trainswithdate
    .groupby("date", "departure_station", "arrival_station")
    .rollup({
      total_num_trips: (d) => op.mean(d.total_num_trips),
      num_late_at_departure: (d) => op.mean(d.num_late_at_departure),
      num_arriving_late: (d) => op.mean(d.num_arriving_late),
      avg_delay_all_departing: (d) => op.mean(d.avg_delay_all_departing),
      avg_delay_all_arriving: (d) => op.mean(d.avg_delay_all_arriving),
    });
  trainsByStations = trainsByStationsAndDate
    .groupby("departure_station", "arrival_station")
    .rollup({
      total_num_trips: (d) => op.sum(d.total_num_trips),
      num_late_at_departure: (d) => op.sum(d.num_late_at_departure),
      num_arriving_late: (d) => op.sum(d.num_arriving_late),
      avg_delay_all_departing: (d) => op.mean(d.avg_delay_all_departing),
      avg_delay_all_arriving: (d) => op.mean(d.avg_delay_all_arriving),
    })
    .derive({
      ratio_late_at_departure: (d) =>
        d.num_late_at_departure / d.total_num_trips,
    });

  // EXERCISES
  createVisualizationsQ5(gares, trainsByStations);
}

function createVisualizationsQ5(gares, trainsByStations) {
  // Change the selection in the flow visualization so when one station in selected, we only see the flows going from and to that station. To achieve that, you have to use the same data to draw the stations and the trips, and Vega aggregation transforms. You can draw inspiration from this example: https://vega.github.io/vega-lite/examples/airport_connections.html
}

createVisualizations();
