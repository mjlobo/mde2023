async function createVisualizations() {
  // ---- DATA LOADING ----- //
  var trains = await aq.loadCSV(
    "https://mjlobo.github.io/teaching/mde/data/2023/small_trains.csv"
  );
  var gares = await aq.loadCSV(
    "https://mjlobo.github.io/teaching/mde/data/2023/garesdep@1.csv"
  );
  var trainswithdate = trains.derive({
    date: (d) => op.datetime(d.year, d.month - 1),
  });

  // ---- TABLE CREATION ----- //

  var trainsByStationsAndDate = trainswithdate
    .groupby("date", "departure_station", "arrival_station")
    .rollup({
      total_num_trips: (d) => op.mean(d.total_num_trips),
      num_late_at_departure: (d) => op.mean(d.num_late_at_departure),
      num_arriving_late: (d) => op.mean(d.num_arriving_late),
      avg_delay_all_departing: (d) => op.mean(d.avg_delay_all_departing),
      avg_delay_all_arriving: (d) => op.mean(d.avg_delay_all_arriving),
    });
  var trainsByStations = trainsByStationsAndDate
    .groupby("departure_station", "arrival_station")
    .rollup({
      total_num_trips: (d) => op.sum(d.total_num_trips),
      num_late_at_departure: (d) => op.sum(d.num_late_at_departure),
      num_arriving_late: (d) => op.sum(d.num_arriving_late),
      avg_delay_all_departing: (d) => op.mean(d.avg_delay_all_departing),
      avg_delay_all_arriving: (d) => op.mean(d.avg_delay_all_arriving),
    })
    .derive({
      ratio_late_at_departure: (d) =>
        d.num_late_at_departure / d.total_num_trips,
    });

  // EXERCISES
  createVisualizationsQ1(gares, trainsByStations);
}

function createVisualizationsQ1(gares, trainsByStations) {
  var garespardepartement = gares.groupby("CODE_DEP").count();
  var chloropeth = {
    $schema: "https://vega.github.io/schema/vega-lite/v5.json",
    width: 500,
    height: 300,
    data: {
      url: "https://mjlobo.github.io/teaching/eivp/departementswithid.json",
      format: { type: "topojson", feature: "departements" },
    },
    transform: [
      {
        lookup: "id", //lookup is the key in the origin table, in this case the topojson
        from: {
          data: {
            values: garespardepartement.objects(), // the table where we will look for the data
          },
          key: "CODE_DEP", // the key in the secondary table
          fields: ["count"], // the fields we will keep
        },
        default: "0", // the default value if there is no match. Even if we want a number, we have to write it as text between ''
      },
    ],
    projection: {
      type: "mercator",
    },
    mark: "geoshape",
    encoding: {
      color: {
        field: "count",
        type: "quantitative",
      },
    },
  };
  vegaEmbed("#chloropeth_1", chloropeth);

  // --- EXERCISE 1 ----
  // 1. Group travels per departure city and calculate the total number of trips.
  var trainsByDepartureStation = trainsByStations
    .groupby("departure_station")
    .rollup({
      total_num_trips: (d) => op.sum(d.total_num_trips),
      num_late_at_departure: (d) => op.sum(d.num_late_at_departure),
      num_arriving_late: (d) => op.sum(d.num_arriving_late),
      avg_delay_all_departing: (d) => op.mean(d.avg_delay_all_departing),
      avg_delay_all_arriving: (d) => op.mean(d.avg_delay_all_arriving),
    });

  // 2. Use Archero function join_left to have in a table the trip and its departure 'departement'.
  var trainsByDepartureStationWithDepartement =
    trainsByDepartureStation.join_left(gares, ["departure_station", "LIBELLE"]);

  // 3. Group by departement and display the choropleth map.
  var trainsByDepartureStationAndDepartement =
    trainsByDepartureStationWithDepartement
      .groupby("CODE_DEP")
      .rollup({
        total_num_trips: (d) => op.sum(d.total_num_trips),
        num_late_at_departure: (d) => op.sum(d.num_late_at_departure),
        num_arriving_late: (d) => op.sum(d.num_arriving_late),
        avg_delay_all_departing: (d) => op.mean(d.avg_delay_all_departing),
        avg_delay_all_arriving: (d) => op.mean(d.avg_delay_all_arriving),
      })
      .derive({
        ratio_late_at_departure: (d) =>
          d.num_late_at_departure / d.total_num_trips,
      });
  var chloropeth_2 = {
    $schema: "https://vega.github.io/schema/vega-lite/v5.json",
    width: 500,
    height: 300,
    data: {
      url: "https://mjlobo.github.io/teaching/eivp/departementswithid.json",
      format: { type: "topojson", feature: "departements" },
    },
    transform: [
      {
        lookup: "id", //lookup corresponds to the key in the origin table, in this case the topojson
        from: {
          data: {
            values: trainsByDepartureStationAndDepartement.objects(), // the table where we will look for the data
          },
          key: "CODE_DEP", // the key in the second table
          fields: ["ratio_late_at_departure"], // the fields we are interested in
        },
        default: "0", // The default value. Even if we want a number we have to write it as a string
      },
    ],
    projection: {
      type: "mercator",
    },
    mark: "geoshape",
    encoding: {
      color: {
        field: "ratio_late_at_departure",
        type: "quantitative",
      },
    },
  };
  vegaEmbed("#chloropeth_2", chloropeth_2);
}

createVisualizations();
