async function createVisualizations() {
  // ---- DATA LOADING ----- //
  var trains = await aq.loadCSV(
    "https://mjlobo.github.io/teaching/mde/data/2023/small_trains.csv"
  );
  var gares = await aq.loadCSV(
    "https://mjlobo.github.io/teaching/mde/data/2023/garesdep@1.csv"
  );
  var trainswithdate = trains.derive({
    date: (d) => op.datetime(d.year, d.month - 1),
  });

  // ---- TABLE CREATION ----- //

  var trainsByStationsAndDate = trainswithdate
    .groupby("date", "departure_station", "arrival_station")
    .rollup({
      total_num_trips: (d) => op.mean(d.total_num_trips),
      num_late_at_departure: (d) => op.mean(d.num_late_at_departure),
      num_arriving_late: (d) => op.mean(d.num_arriving_late),
    });
  var trainsByStations = trainsByStationsAndDate
    .groupby("departure_station", "arrival_station")
    .rollup({
      total_num_trips: (d) => op.sum(d.total_num_trips),
      num_late_at_departure: (d) => op.sum(d.num_late_at_departure),
      num_arriving_late: (d) => op.sum(d.num_arriving_late),
    })
    .derive({
      ratio_late_at_departure: (d) =>
        d.num_late_at_departure / d.total_num_trips,
    });

  // EXERCISES
  createVisualizationsQ4(gares, trainsByStations);
}

function createVisualizationsQ4(gares, trainsByStations) {
  var trainsByArrivalStation = trainsByStations
    .groupby("arrival_station")
    .rollup({
      total_num_trips: (d) => op.sum(d.total_num_trips),
      num_late_at_departure: (d) => op.sum(d.num_late_at_departure),
      num_arriving_late: (d) => op.sum(d.num_arriving_late),
    });

  var trainsByArrivalWithCoords = trainsByArrivalStation
    .join_left(gares, ["arrival_station", "LIBELLE"])
    .filter((d) => d.LIBELLE != null)
    .reify();

  var trainsByDepartureStation = trainsByStations
    .groupby("departure_station")
    .rollup({
      total_num_trips: (d) => op.sum(d.total_num_trips),
      num_late_at_departure: (d) => op.sum(d.num_late_at_departure),
      num_arriving_late: (d) => op.sum(d.num_arriving_late),
    });

  var trainsByDepartureWithCoords = trainsByDepartureStation
    .join_left(gares, ["departure_station", "LIBELLE"])
    .filter((d) => d.LIBELLE != null)
    .reify();

  var trainsByDepartureWithCoordsForJoin = trainsByDepartureWithCoords.select({
    departure_station: "departure_station",
    total_num_trips: "total_num_trips_departure",
  });

  var trainsByArrivalWithCoordsForJoin = trainsByArrivalWithCoords.select({
    arrival_station: "arrival_station",
    total_num_trips: "total_num_trips_arrival",
    X_WGS84: "X_WGS84",
    Y_WGS84: "Y_WGS84",
  });

  var trainsWithArrivalAndDeparture =
    trainsByDepartureWithCoordsForJoin.join_left(
      trainsByArrivalWithCoordsForJoin,
      ["departure_station", "arrival_station"]
    );

  var trainsWithDiff = trainsWithArrivalAndDeparture.derive({
    diff_arrival_departure: (d) =>
      d.total_num_trips_arrival - d.total_num_trips_departure,
  });

  var further1 = {
    $schema: "https://vega.github.io/schema/vega-lite/v5.json",
    width: 500,
    height: 300,
    layer: [
      {
        data: {
          url: "https://mjlobo.github.io/teaching/eivp/departements.json",
          format: {
            type: "topojson",
            feature: "departements",
          },
        },
        projection: {
          type: "mercator",
        },
        mark: {
          type: "geoshape",
          fill: "lightgray",
          stroke: "white",
        },
      },
      {
        data: {
          values: trainsWithDiff.objects(),
        },
        projection: {
          type: "mercator",
        },
        mark: { type: "circle" },
        encoding: {
          longitude: {
            field: "X_WGS84",
            type: "quantitative",
          },
          latitude: {
            field: "Y_WGS84",
            type: "quantitative",
          },
          size: {
            field: "diff_arrival_departure",
            type: "quantitative",
          },
          color: {
            value: "steelblue",
          },
        },
      },
    ],
  };
  vegaEmbed("#further_1", further1);

  var further2 = {
    $schema: "https://vega.github.io/schema/vega-lite/v5.json",
    width: 500,
    height: 300,
    layer: [
      {
        data: {
          url: "https://mjlobo.github.io/teaching/eivp/departements.json",
          format: {
            type: "topojson",
            feature: "departements",
          },
        },
        projection: {
          type: "mercator",
        },
        mark: {
          type: "geoshape",
          fill: "lightgray",
          stroke: "white",
        },
      },
      {
        data: {
          values: trainsWithDiff.objects(),
        },
        projection: {
          type: "mercator",
        },
        mark: { type: "circle" },
        encoding: {
          longitude: {
            field: "X_WGS84",
            type: "quantitative",
          },
          latitude: {
            field: "Y_WGS84",
            type: "quantitative",
          },
          size: {
            value: 100,
          },
          color: {
            field: "diff_arrival_departure",
            type: "quantitative",
            scale: { scheme: "blueorange" },
          },
        },
      },
    ],
  };
  vegaEmbed("#further_2", further2);

  var trainsWithDiffBoolean = trainsWithDiff.derive({
    is_arrival_bigger: (d) => (d.diff_arrival_departure > 0 ? "true" : "false"),
  });

  var further3 = {
    $schema: "https://vega.github.io/schema/vega-lite/v5.json",
    width: 500,
    height: 300,
    layer: [
      {
        data: {
          url: "https://mjlobo.github.io/teaching/eivp/departements.json",
          format: {
            type: "topojson",
            feature: "departements",
          },
        },
        projection: {
          type: "mercator",
        },
        mark: {
          type: "geoshape",
          fill: "lightgray",
          stroke: "white",
        },
      },
      {
        data: {
          values: trainsWithDiffBoolean.objects(),
        },
        projection: {
          type: "mercator",
        },
        mark: { type: "circle" },
        encoding: {
          longitude: {
            field: "X_WGS84",
            type: "quantitative",
          },
          latitude: {
            field: "Y_WGS84",
            type: "quantitative",
          },
          size: {
            value: 100,
          },
          color: {
            field: "is_arrival_bigger",
          },
        },
      },
    ],
  };
  vegaEmbed("#further_3", further3);
}

createVisualizations();
